#ifndef INPUTDIALOG_H
#define INPUTDIALOG_H

#include <QDialog>
#include <QLineEdit>

/**
 * \class InputDialog
 * \brief The InputDialog class provides a dialog for inputting system parameters.
 */
class InputDialog : public QDialog {
    Q_OBJECT

public:
    /**
     * \brief Constructs the InputDialog object.
     * \param parent The parent widget.
     */
    explicit InputDialog(QWidget *parent = nullptr);

    /**
     * \brief Gets the inputted temperature value.
     * \return The temperature value.
     */
    double getTemperature() const;

    /**
     * \brief Gets the inputted humidity value.
     * \return The humidity value.
     */
    double getHumidity() const;

    /**
     * \brief Gets the inputted pressure value.
     * \return The pressure value.
     */
    double getPressure() const;

private:
    QLineEdit *temperatureEdit; ///< Line edit for inputting the temperature.
    QLineEdit *humidityEdit; ///< Line edit for inputting the humidity.
    QLineEdit *pressureEdit; ///< Line edit for inputting the pressure.
};

#endif // INPUTDIALOG_H
