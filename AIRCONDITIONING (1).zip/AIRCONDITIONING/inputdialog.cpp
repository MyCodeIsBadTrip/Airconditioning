#include "inputdialog.h"
#include <QVBoxLayout>
#include <QLabel>
#include <QDialogButtonBox>

/**
 * \brief Constructs the InputDialog object.
 * \param parent The parent widget.
 */
InputDialog::InputDialog(QWidget *parent) : QDialog(parent) {
    QVBoxLayout *layout = new QVBoxLayout(this);

    layout->addWidget(new QLabel("Temperature:", this));
    temperatureEdit = new QLineEdit(this);
    layout->addWidget(temperatureEdit);

    layout->addWidget(new QLabel("Humidity:", this));
    humidityEdit = new QLineEdit(this);
    layout->addWidget(humidityEdit);

    layout->addWidget(new QLabel("Pressure:", this));
    pressureEdit = new QLineEdit(this);
    layout->addWidget(pressureEdit);

    QDialogButtonBox *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
    connect(buttonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);
    layout->addWidget(buttonBox);
}

/**
 * \brief Gets the inputted temperature value.
 * \return The temperature value.
 */
double InputDialog::getTemperature() const {
    return temperatureEdit->text().toDouble();
}

/**
 * \brief Gets the inputted humidity value.
 * \return The humidity value.
 */
double InputDialog::getHumidity() const {
    return humidityEdit->text().toDouble();
}

/**
 * \brief Gets the inputted pressure value.
 * \return The pressure value.
 */
double InputDialog::getPressure() const {
    return pressureEdit->text().toDouble();
}
