#ifndef AIRCONDITIONINGAPP_H
#define AIRCONDITIONINGAPP_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QComboBox>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsRectItem>
#include <QFile>
#include <QXmlStreamWriter>
#include <QXmlStreamReader>

/**
 * \class AirConditioningApp
 * \brief The AirConditioningApp class provides the main application interface for controlling the air conditioning system.
 */
class AirConditioningApp : public QWidget {
    Q_OBJECT

public:
    /**
     * \brief Constructs the AirConditioningApp object.
     * \param parent The parent widget.
     */
    AirConditioningApp(QWidget *parent = nullptr);

protected slots:
    /**
     * \brief Toggles the power state of the air conditioning system.
     */
    void togglePower();

    /**
     * \brief Opens a dialog to input system parameters.
     */
    void openInputDialog();

    /**
     * \brief Switches between light and dark styles.
     */
    void toggleStyle();

    /**
     * \brief Changes the temperature unit.
     * \param index The index of the selected temperature unit.
     */
    void changeTempUnit(int index);

    /**
     * \brief Changes the pressure unit.
     * \param index The index of the selected pressure unit.
     */
    void changePressureUnit(int index);

    /**
     * \brief Reads user settings from an XML file.
     */
    void readSettings();

    /**
     * \brief Writes user settings to an XML file.
     */
    void writeSettings();

    /**
     * \brief Updates the graphical representation of the system state.
     */
    void updateSystemState();

    /**
     * \brief Updates the temperature label based on the selected unit.
     */
    void updateTemperatureLabel();

    /**
     * \brief Updates the humidity label
     */
    void updateHumidityLabel();

    /**
     * \brief Updates the pressure label based on the selected unit.
     */
    void updatePressureLabel();

private:
    QLabel *temperatureLabel; ///< Label to display the temperature.
    QLabel *humidityLabel; ///< Label to display the humidity.
    QLabel *pressureLabel; ///< Label to display the pressure.
    QComboBox *tempUnitComboBox; ///< Combo box for selecting the temperature unit.
    QComboBox *pressureUnitComboBox; ///< Combo box for selecting the pressure unit.
    QPushButton *togglePowerButton; ///< Button to toggle the power state.
    QPushButton *inputParamsButton; ///< Button to open the input parameters dialog.
    QPushButton *toggleStyleButton; ///< Button to switch between light and dark styles.
    QGraphicsScene *scene; ///< Graphics scene for displaying the system state.
    QGraphicsRectItem *block1; ///< Graphics item for block 1.
    QGraphicsRectItem *block2; ///< Graphics item for block 2.
    QGraphicsRectItem *block3; ///< Graphics item for block 3.

    int tempUnitIndex; ///< Index of the selected temperature unit.
    int pressureUnitIndex; ///< Index of the selected pressure unit.
    double temperature; ///< Current temperature value.
    double humidity; ///< Current humidity value.
    double pressure; ///< Current pressure value.
    bool darkStyle; ///< Flag to indicate the selected style (dark or light).
};

#endif // AIRCONDITIONINGAPP_H
