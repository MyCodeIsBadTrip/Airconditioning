#include "airconditioningapp.h"
#include "inputdialog.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGraphicsEllipseItem>
#include <QDebug>
#include <QApplication>
#include <QFile>
#include <QXmlStreamWriter>
#include <QXmlStreamReader>

/**
 * \brief Constructs the AirConditioningApp object.
 * \param parent The parent widget.
 */
AirConditioningApp::AirConditioningApp(QWidget *parent) : QWidget(parent), tempUnitIndex(0), pressureUnitIndex(0), temperature(20), humidity(50), pressure(1013), darkStyle(false) {
    QVBoxLayout *mainLayout = new QVBoxLayout(this);

    temperatureLabel = new QLabel("Temperature: 20 °C", this);
    humidityLabel = new QLabel("Humidity: 50 %", this);
    pressureLabel = new QLabel("Pressure: 1013 Pa", this);

    mainLayout->addWidget(temperatureLabel);
    mainLayout->addWidget(humidityLabel);
    mainLayout->addWidget(pressureLabel);

    QHBoxLayout *controlsLayout = new QHBoxLayout();

    togglePowerButton = new QPushButton("Power", this);
    inputParamsButton = new QPushButton("Input Parameters", this);
    toggleStyleButton = new QPushButton("Toggle Style", this);

    controlsLayout->addWidget(togglePowerButton);
    controlsLayout->addWidget(inputParamsButton);
    controlsLayout->addWidget(toggleStyleButton);

    mainLayout->addLayout(controlsLayout);

    tempUnitComboBox = new QComboBox(this);
    tempUnitComboBox->addItem("Celsius");
    tempUnitComboBox->addItem("Fahrenheit");
    tempUnitComboBox->addItem("Kelvin");
    mainLayout->addWidget(tempUnitComboBox);

    pressureUnitComboBox = new QComboBox(this);
    pressureUnitComboBox->addItem("Pascal");
    pressureUnitComboBox->addItem("mmHg");
    mainLayout->addWidget(pressureUnitComboBox);

    scene = new QGraphicsScene(this);
    QGraphicsView *view = new QGraphicsView(scene, this);
    mainLayout->addWidget(view);

    block1 = scene->addRect(0, 0, 100, 100, QPen(), QBrush(Qt::green));
    block2 = scene->addRect(110, 0, 100, 100, QPen(), QBrush(Qt::yellow));
    block3 = scene->addRect(220, 0, 100, 100, QPen(), QBrush(Qt::red));

    connect(togglePowerButton, &QPushButton::clicked, this, &AirConditioningApp::togglePower);
    connect(inputParamsButton, &QPushButton::clicked, this, &AirConditioningApp::openInputDialog);
    connect(toggleStyleButton, &QPushButton::clicked, this, &AirConditioningApp::toggleStyle);
    connect(tempUnitComboBox, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &AirConditioningApp::changeTempUnit);
    connect(pressureUnitComboBox, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &AirConditioningApp::changePressureUnit);

    readSettings();
    updateTemperatureLabel();
    updatePressureLabel();
    updateSystemState();
}

/**
 * \brief Toggles the power state of the air conditioning system.
 */
void AirConditioningApp::togglePower() {
    qDebug() << "Power toggled";
}

/**
 * \brief Opens a dialog to input system parameters.
 */
void AirConditioningApp::openInputDialog() {
    InputDialog dialog(this);
    if (dialog.exec() == QDialog::Accepted) {
        temperature = dialog.getTemperature();
        humidity = dialog.getHumidity();
        pressure = dialog.getPressure();
        updateTemperatureLabel();
        updateHumidityLabel();
        updatePressureLabel();
        writeSettings();
    }
}

/**
 * \brief Switches between light and dark styles.
 */
void AirConditioningApp::toggleStyle() {
    darkStyle = !darkStyle;
    if (darkStyle) {
        qApp->setStyleSheet("QWidget { background-color: #2b2b2b; color: #ffffff; }");
    } else {
        qApp->setStyleSheet("");
    }
    updateSystemState();
    writeSettings();
}

/**
 * \brief Changes the temperature unit.
 * \param index The index of the selected temperature unit.
 */
void AirConditioningApp::changeTempUnit(int index) {
    tempUnitIndex = index;
    updateTemperatureLabel();
    writeSettings();
}

/**
 * \brief Changes the pressure unit.
 * \param index The index of the selected pressure unit.
 */
void AirConditioningApp::changePressureUnit(int index) {
    pressureUnitIndex = index;
    updatePressureLabel();
    writeSettings();
}

/**
 * \brief Reads user settings from an XML file.
 */
void AirConditioningApp::readSettings() {
    QFile file("config.xml");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open config file for reading";
        return;
    }

    QXmlStreamReader reader(&file);
    while (!reader.atEnd() && !reader.hasError()) {
        reader.readNext();
        if (reader.isStartElement()) {
            if (reader.name() == "tempUnitIndex") {
                tempUnitIndex = reader.readElementText().toInt();
            } else if (reader.name() == "pressureUnitIndex") {
                pressureUnitIndex = reader.readElementText().toInt();
            } else if (reader.name() == "temperature") {
                temperature = reader.readElementText().toDouble();
            } else if (reader.name() == "humidity") {
                humidity = reader.readElementText().toDouble();
            } else if (reader.name() == "pressure") {
                pressure = reader.readElementText().toDouble();
            } else if (reader.name() == "darkStyle") {
                darkStyle = reader.readElementText().toInt();
            }
        }
    }
    file.close();
}

/**
 * \brief Writes user settings to an XML file.
 */
void AirConditioningApp::writeSettings() {
    QFile file("config.xml");
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qDebug() << "Failed to open config file for writing";
        return;
    }

    QXmlStreamWriter writer(&file);
    writer.setAutoFormatting(true);
    writer.writeStartDocument();
    writer.writeStartElement("settings");

    writer.writeTextElement("tempUnitIndex", QString::number(tempUnitIndex));
    writer.writeTextElement("pressureUnitIndex", QString::number(pressureUnitIndex));
    writer.writeTextElement("temperature", QString::number(temperature));
    writer.writeTextElement("humidity", QString::number(humidity));
    writer.writeTextElement("pressure", QString::number(pressure));
    writer.writeTextElement("darkStyle", QString::number(darkStyle));

    writer.writeEndElement();
    writer.writeEndDocument();
    file.close();
}

/**
 * \brief Updates the graphical representation of the system state.
 */
void AirConditioningApp::updateSystemState() {
    block1->setBrush(QBrush(darkStyle ? Qt::green : Qt::red));
    block2->setBrush(QBrush(darkStyle ? Qt::yellow : Qt::blue));
    block3->setBrush(QBrush(darkStyle ? Qt::red : Qt::green));
}

/**
 * \brief Updates the temperature label based on the selected unit.
 */
void AirConditioningApp::updateTemperatureLabel() {
    QString tempText;
    switch (tempUnitIndex) {
        case 0:
            tempText = QString("Temperature: %1 °C").arg(temperature);
            break;
        case 1:
            tempText = QString("Temperature: %1 °F").arg(temperature * 9 / 5 + 32);
            break;
        case 2:
            tempText = QString("Temperature: %1 K").arg(temperature + 273.15);
            break;
    }
    temperatureLabel->setText(tempText);
}

/**
 * \brief Updates the humidity label.
 */
void AirConditioningApp::updateHumidityLabel() {
    humidityLabel->setText(QString("Humidity: %1 %").arg(humidity));
}

/**
 * \brief Updates the pressure label based on the selected unit.
 */
void AirConditioningApp::updatePressureLabel() {
    QString pressureText;
    switch (pressureUnitIndex) {
        case 0:
            pressureText = QString("Pressure: %1 Pa").arg(pressure);
            break;
        case 1:
            pressureText = QString("Pressure: %1 mmHg").arg(pressure * 0.00750062);
            break;
    }
    pressureLabel->setText(pressureText);
}
